$(document).ready(function(){
						

$(".E0413Ex02").html("In the following sentence, click on the suitable coordinating conjunction from the given options.")
$(".E0413Ex03").html("In the following sentence, click on the suitable conjunction from the given options.")
$(".E0510Ex01").html("In the following sentence, click on the correct preposition from the given options.")
$(".E0511Ex04").html("In the following sentence, click on the correct conjunction from the given options.")


$(".E0422Ex02").html("The given sentence in blue has a bold word. It has two or three optional sentences. One of them has the correct antonym of that bold word. Tick that sentence.")


$(".E0422Ex03").html("Find the antonym of the highlighted word in the given sentence and click on it.")

$(".E0423Ex03").html("Complete the given sentence with the correct homophone.")

$(".E0401Ex06").html("There are two expressions. One of them is a run Ã¢â‚¬â€œ on sentence. Select the one that is run Ã¢â‚¬â€œ on.")

$(".E0517Ex03").html("In given sentence one word is pink. Choose whether the pink word is a verb, noun or adjective.")

$(".E0508Ex03").html("The following sentences have no articles. Choose the correct answer.")

$(".E0301Ex03").html("Check whether the given sentence is a fragment or run - on. Click the right answer.")

/*$(".E0303Ex04").html("Read the following sentence. Write Ã¢â‚¬ËœMÃ¢â‚¬â„¢ if the noun is masculine and Ã¢â‚¬ËœFÃ¢â‚¬â„¢ if it is feminine gender.")
*/
$(".E0305Ex02").html("Choose the correct pronoun from bracket and write it in the blank.")

/*$(".E0309Ex02").html("Complete the sentence with a suitable article Ã¢â‚¬â€œ Ã¢â‚¬ËœaÃ¢â‚¬â„¢ or Ã¢â‚¬Ëœan.Ã¢â‚¬â„¢")*/

$(".E0310Ex05").html("Fill in the blank with suitable form of the describing word given in the bracket.")

$(".E0517Ex03").html("In given sentence one word is pink. Choose whether the pink word is a verb, noun or adjective.")

$(".E0416Ex02").html("Punctuate the following sentence correctly.")


$(".E0303Ex04").html("Read the following sentence. Write 'M' if the noun is masculine and 'F' if it is feminine gender.")

$(".E0505Ex5a").html("Select the verb and the tense.")
/*$(".E0309Ex02").html("Complete the sentence with a suitable article - 'a' or 'an'.")*/


$(".E0309Ex02").html("Complete the sentence with a suitable article - 'a' or 'an'.")

$(".E0508Ex03").html("The following sentence have no articles. Choose the correct answer.")

$(".E0401Ex13").html("Identify the sentence as simple or compound by clicking on the correct option.")

$(".E0319Ex05").html("Identify on the basis of suffixes the parts of speech of the given word and click on the correct option.")

$(".E0514Ex02").html("The given statement has two options in Direct or Indirect speech. Choose the correct Direct or Indirect speech.")

$(".E0302Ex11").html("Given below is a list of Compound Nouns. Choose the correct one and fill it in the blank in the given sentence.")


$(".E0310Ex02").html("In the given sentence, click on the adjective that tells you how many.")

$(".E0501BEx02").html("Match the subject in Column A with appopriate predicates in Column B.")
$(".E0210Ex02").html("Click on the suitable adjective to fill the blank in the following sentence.")
$(".E0208Ex05").html(" Click on the suitable past tense form of 'to be' - (i.e. 'was', 'were') to fill the blank in the given sentence.")
$(".E0525Ex02").html("The word 'pick-up' has been used in three different ways. Read the sentence below and Choose the correct meaning of 'pick-up' from the given option.")
$(".GEEN1103011Activity1-MC").html("Read the following sentence and click on the correct answer.")
$(".GEEN1103081Activity5-RW").html("Rewrite the following sentence after correcting it.")
$(".GEEN1103081Activity7-RW").html("Rewrite the following sentence after correcting it.")
$(".GEEN1103081Activity8-MC").html("Four words are given below out of which only one is spelt correctly. Click on the correctly spelt word.")

$(".GEEN1103083Activity1").html("Fill in the blank with an appropriate word or phrase from the two options given against each sentence.")

$(".GEEN1103121Activity1-MC").html("In the following sentence fill in the blank with a suitable word from the bracket.")

$(".ERBG051actvity2").html("Determine whether in the given statement the author's purpose is to entertain, persuade or inform.")
$(".G1102035Act1-RW").html("Read the sentence and mark Correct if the sentence is correctly punctuated. Rewrite the sentence if the punctuation is incorrect.")

$(".E0201Ex09").html("Identify whether the given sentence is a statement, a command, a question or an exclamation.")
$(".E0203Ex07").html("The given sentence has an error. Click on it and write the correct word.")

$(".E0102Ex6").html("Select the proper Noun in the following sentence.")
$(".E08011Ex01").html("Identify the sentence from the given choices. Click on the correct answer.")

$(".E08011Ex02").html("Identify the phrase in the given choices. Click on the correct answer.")
$(".E08031Ex05").html("Join the following pair of sentences by using proper Relative Pronoun.")
$(".E0501Ex01").html("In the following sentence click on the word(s) that form the Complete Subject and the Main Subject")
$(".E0501Ex03").html("Rearrange the following words to form a Meaningful Sentence.")
$(".E0501BEx01").html("Click on the complete predicate of the given sentence.")
$(".E0502Ex07").html("Identify whether the given noun is countable or uncountable")
$(".E0502Ex09").html("Choose the correct plural of the given noun.")
$(".E0505Ex02a").html("Click on the main verb.")
$(".E0505Ex2b").html("Click on the main verb.")
$(".E0505Ex5a").html("Click on the verb and the tense.")
$(".E0505Ex06").html("Fill in the blank with the correct form of the verb according to the direction given in brackets.")
$(".E0505Ex07").html("Fill in the blank with the correct form of the verb given in brackets.")
$(".E0506Ex01").html("Fill in the blank with the past participle of the given verb.")
$(".E0506Ex03").html("Identify whether the underlined word is a noun or an adjective.")
$(".E0506Ex05").html("Click on the word in the following sentence and identify whether it is a Gerund or Present Participle.")
$(".E0506Ex06").html("Fill in the blank with the correct form of the word or phrase given in brackets.")
$(".E0507Ex03").html("Fill in the blank with the suitable adjective given within brackets to complete the sentence.")
$(".E0508Ex03").html("The following sentence has no articles. Choose the correct answer.")

$(".E0509Ex03").html("Form an adverb from the given adjective")
$(".E0510Ex02").html("In the following sentence, click on the correct preposition from the given options.")
$(".E0510Ex03").html("Fill in the blank with the correct preposition.")
$(".E0510Ex04").html("Fill in the blank with a suitable preposition")
$(".E0511Ex05").html("Join the pair of sentences with a coordinating conjunction (or, but, and, so, for) to form one sentence.")
$(".E45033Ex02").html("Write the noun of the given verb by adding a prefix or suffix to it:") /////17-05
$(".E45033Ex03").html("Convert the given noun into an adjective by adding a prefix or suffix to it if required:")
$(".E45033Ex04").html("Convert the given word into an abstract noun by adding a suffix.")
$(".E45033Ex05").html("Convert the given word into an abstract noun by adding a suffix.")
$(".E45037Ex01").html("Unscramble the letters given below to form a meaningful word.")

$(".E45039Ex01").html("Click on the heading to which the following group of words belongs.")
$(".E450310Ex01").html("Select the correct spelling of the word to complete the given sentence.")
$(".GEEN1103011Activity3").html("Fill in the blanks with the correct word/words included in the parenthesis.")
$(".GEEN1103021Activity1A").html("Read the passage below. The underlined fragment is incorrect. Click on the correct option.")
$(".GEEN1103021Activity1B").html("Read the passage below. The underlined fragment is incorrect. Click on the correct option.")
$(".GEEN1103051Activity1-MC").html("There are three alternatives to fill in the blank. Only one of them is correct. Click on the correct option.")
$(".GEEN1103051Activity2").html("Use one word/phrase for the following information. Choose one of the two options included in the parenthesis.")//////22-07-2022
              

}); //////end of Main/////////

